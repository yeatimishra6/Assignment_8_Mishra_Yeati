﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment_8_Mishra_Yeati.Models
{
    public class Info
    {
        public String teamName { get; set; }
        public string birthDay { get; set; }
        public string collegeProgram { get; set; }
        public string collegeYear { get; set; }

        public double id { get; set; }
    }
}
