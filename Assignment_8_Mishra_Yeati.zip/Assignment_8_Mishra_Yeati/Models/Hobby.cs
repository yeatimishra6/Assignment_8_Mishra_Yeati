﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment_8_Mishra_Yeati.Models
{
    public class Hobby
    {
        public string favSport {get; set;}
        public string freeTimeActivity { get; set; }
        public int id { get; set; }

        public string favMovie { get; set; }

        public string favPlaceToTravel { get; set; }
    }
}
