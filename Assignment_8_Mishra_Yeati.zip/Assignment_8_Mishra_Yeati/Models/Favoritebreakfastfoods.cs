﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment_8_Mishra_Yeati.Models
{
    public class Favoritebreakfastfoods
    {
        public string typeOfEggsYouLike { get; set; }
        public string pancakeOrWaffle { get; set; }
        public string typeOfDrink { get; set; }
        public int id { get; set; }

        public string favBreakfastPlace { get; set; }

    }
}
