﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment_8_Mishra_Yeati.Models
{
    public class Color
    {
        public string schoolColor { get; set; }
        public string memberCommonFavColor { get; set; }
        
        public int id { get; set; }

        public int numberOfColorInSchoolLogo { get; set; }

        public int peopleInTheTeam { get; set; }
    }
}
